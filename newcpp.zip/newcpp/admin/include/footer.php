 <footer class="footer" style="text-align: center;"> Online Grocery Ordering System  by - <a href="">MR Prajyot</a> </footer>
